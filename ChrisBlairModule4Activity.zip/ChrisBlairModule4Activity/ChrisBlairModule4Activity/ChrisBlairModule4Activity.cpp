// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>


//Custom exception class that overrides the what method
class CustomException : public std::exception {
public: 
    const char* what() const noexcept override {
        return "Custom exception: Some custom error message...";
    }
};


bool do_even_more_custom_application_logic()
{
    throw std::exception("Something went wrong...");

    std::cout << "Running Even More Custom Application Logic." << std::endl;

    return true;
}
void do_custom_application_logic()
{
    std::cout << "Running Custom Application Logic." << std::endl;

    //standard exception handler, followed by a custom exception
    try {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception& e) {
        std::cerr << "Exception caught in do_custom_application_logic: " << e.what() << std::endl;
    }

    throw CustomException();

    std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
    //throwing an error if we divide by 0
    if (den == 0.0f) {
        throw std::runtime_error("Error: Dividing by 0 is not allowed.");
    }

    return (num / den);
}

void do_division() noexcept
{
    //exception handler for the do_division function
    try {

        float numerator = 10.0f;
        float denominator = 0;

        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::exception& e) {
        std::cerr << "Exception in do division..." << e.what() << std::endl;
    }

}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    //adding exception handlers for different error types
    try {
        do_division();
        do_custom_application_logic();
    }
    catch (const CustomException& e) {
        std::cerr << "Custom Exception..." << e.what() << std::endl;
    }
    catch (const std::exception& e) {
        std::cerr << "Standard exception..." << e.what() << std::endl;
    }
    catch (...) {
        std::cerr << "Uknown exception..." << std::endl;
    }
   
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu